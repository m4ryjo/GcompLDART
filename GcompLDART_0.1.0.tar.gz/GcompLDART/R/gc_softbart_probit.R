gc_softbart_probit <- function(X, Y, num_tree = 20,
                            k = 1, hypers = NULL, opts = NULL, verbose = TRUE) {

  ## Get design matricies and groups for categorical

  # dv <- dummyVars(formula, data)
  # terms <- attr(dv$terms, "term.labels")
  # group <- dummy_assign(dv)
  # suppressWarnings({
  #   X_train <- predict(dv, data)
  #   X_test  <- predict(dv, test_data)
  # })
  # Y_train <- model.response(model.frame(formula, data))
  # Y_test  <- model.response(model.frame(formula, test_data))
  Y_train <- Y #model.response(model.frame(formula, data))
  X_train <- X

  stopifnot(length(table(Y_train)) == 2)

  pnorm_offset <- mean(Y_train)
  offset <- qnorm(pnorm_offset)

  ## Set up hypers

  if(is.null(hypers)) {
    hypers <- Hypers(X = X_train, Y = Y_train)
  } else {
    hypers$X <- X_train
    hypers$Y <- Y_train
  }
  
  hypers$sigma_mu = 3 / k / sqrt(num_tree)
  hypers$sigma <- 1
  hypers$sigma_hat <- 1
  hypers$num_tree <- num_tree
  hypers$group <- (1:ncol(X_train) - 1)

  ## Set up opts

  if(is.null(opts)) {
    opts <- Opts()
  }
  opts$update_sigma <- FALSE
  opts$num_print <- 2147483647

  ## Normalize!

  make_01_norm <- function(x) {
    a <- min(x)
    b <- max(x)
    return(function(y) (y - a) / (b - a))
  }

  ecdfs   <- list()
  for(i in 1:ncol(X_train)) {
    ecdfs[[i]] <- ecdf(X_train[,i])
    if(length(unique(X_train[,i])) == 1) ecdfs[[i]] <- identity
    if(length(unique(X_train[,i])) == 2) ecdfs[[i]] <- make_01_norm(X_train[,i])
  }
  for(i in 1:ncol(X_train)) {
    X_train[,i] <- ecdfs[[i]](X_train[,i])
  }

  ## Make forest ----

  probit_forest <- MakeForest(hypers, opts, FALSE)

  ## Initialize Z

  mu <- as.numeric(probit_forest$do_predict(X_train))
  lower <- ifelse(Y_train == 0, -Inf, 0)
  upper <- ifelse(Y_train == 0, 0, Inf)

  ## Initialize output

  #  mu_train  <- matrix(NA, nrow = opts$num_save, ncol = length(Y_train))
  #  sigma_mu  <- numeric(opts$num_save)
  varcounts <- matrix(NA, nrow = opts$num_save, ncol = ncol(X_train))


  ## Warmup
  for(i in 1:opts$num_burn) {
    ## Sample Z
    Z <- rtruncnorm(n = length(Y_train), a = lower, b = upper,
                    mean = mu + offset, sd = 1)
    ## Update R
    mu <- probit_forest$do_gibbs(X_train, Z - offset, X_train, 1)
  }

  ## Save
  for(i in 1:opts$num_save) {
    for(j in 1:opts$num_thin) {
      ## Sample Z
      Z <- rtruncnorm(n = length(Y_train), a = lower, b = upper,
                      mean = offset + mu, sd = 1)
      ## Update R
      mu <- probit_forest$do_gibbs(X_train, Z - offset, X_train, 1)
    }

    #sigma_mu[i]   <- probit_forest$get_sigma_mu()
    #varcounts[i,] <- probit_forest$get_counts()
    #mu_train[i,]  <- mu + offset

  }

  #p_train <- pnorm(mu_train)

  colnames(varcounts) <- colnames(X_train)

  out <- list(#sigma_mu = sigma_mu,
    #var_counts = varcounts, #mu_train = mu_train,
    #p_train = p_train,
    #mu_train_mean = colMeans(mu_train),
    #p_train_mean = colMeans(p_train),
    offset = offset,
    #pnorm_offset = pnorm(offset),
    #formula = formula,
    ecdfs = ecdfs,
    opts = opts,
    forest = probit_forest)

  class(out) <- "softbart_probit"
  return(out)

}
