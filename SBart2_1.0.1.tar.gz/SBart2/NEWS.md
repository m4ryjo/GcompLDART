# SoftBart

## SoftBart 1.0.1

- Added vignette to the package explaining generic usage. This can be accessed
  by running `browseVignettes('SoftBart')`.