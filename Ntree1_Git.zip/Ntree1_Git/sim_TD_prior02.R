############################################################
library(SBart2)
library(BART)
library(MASS)
library(foreach)
library(doParallel)

sim_fried <- function(N, P, Sigma, sigma, lambda) {
  rawvars <- mvrnorm(N, rep(0, P), Sigma)
  X <- pnorm(rawvars)
  mu <- lambda[1] * (10 * sin(pi * X[,1] * X[,2]) + 20 * (X[,3] - 0.5)^2 + 10 * X[,4] + 5 * X[,5]) +
        lambda[2] * (10 * sin(pi * X[,6] * X[,7]) + 20 * (X[,8] - 0.5)^2 + 10 * X[,9] + 5 * X[,10]) +
        lambda[3] * (10 * sin(pi * X[,11] * X[,12]) + 20 * (X[,13] - 0.5)^2 + 10 * X[,14] + 5 * X[,15]) +
        lambda[4] * (10 * sin(pi * X[,16] * X[,17]) + 20 * (X[,18] - 0.5)^2 + 10 * X[,19] + 5 * X[,20])
  Y <- mu + sigma * rnorm(N)
  #X <- round(X, 1)
  return(data.frame(X = X, Y = Y, mu = mu))
}

coverage <- function(my, my_fit, proc = 0.95){
  if(length(my)==1){
    out <- ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                    my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0)
  } else {
    out <- mean(ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                         my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0))
  }
  
  return(out)
}  

########################################################
Ntree <- 1  # 1, 10, 100
Nit <- 4000 

n <- 500 # sample size 100, 500, 1500
times_sim <- rep(1:4, each = 5) # grouping variable

# l <- 1
#k <- 3
#lambda <- c(0.25,0.5,0.75,1)^k
lambda <- c(0,0,0,1)
#lambda <- c(0.25,0.5,0.75,1)

a1 <- 0.4
a2 <- 0.2
a3 <- 0.1
sig <- 10  # 1?, 10, 25

Sig<-matrix(c(c(1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0,0),
              c(0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0),
              c(0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0),
              c(0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0),
              c(0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3),
              c(a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0),
              c(0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0),
              c(0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0),
              c(0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0),
              c(0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2),
              c(a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0),
              c(0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0),
              c(0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0),
              c(0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0),
              c(0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1),
              c(a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0),
              c(0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0),
              c(0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0),
              c(0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0),
              c(0,0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1)), 20, 20, byrow = TRUE)

########################################################
# fna2 <- paste("Soft_sim_outsample_n",n,"_Ntree",Ntree,"_l2",sep="") # lambda <- (c(0.25,0.5,0.75,1)^k)
# fna2 <- paste("Soft_sim_outsample_n",n,"_Ntree",Ntree,"_l1",sep="") #lambda <- c(0.25,0.5,0.75,1)
fna2 <- paste("Soft_sim_outsample_n",n,"_Ntree",Ntree,"_l0",sep="") # lambda <- c(0,0,0,1)

true_mean <- sim_fried(100000, 20, Sig, sig, lambda)$mu
mtm <- median(true_mean)
sdtm <- sd(true_mean)

myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:1000, .packages = c("MASS", "SBart2", "BART")) %dopar% {
  training_data <- sim_fried(n, 20, Sig, sig, lambda)
  test_data <- sim_fried(n, 20, Sig, sig, lambda)
  X_train <- model.matrix(Y ~ . - 1 - mu, data = training_data)
  X_test <- model.matrix(Y ~ . - 1 - mu, data = test_data)
  
  training_data_sub <- training_data[,16:22]
  test_data_sub <- test_data[,16:22]
  X_train_sub <- model.matrix(Y ~ . - 1 - mu, data = training_data_sub)
  X_test_sub <- model.matrix(Y ~ . - 1 - mu, data = test_data_sub)
  
  fitted_LBART <- softbart_regression(Y ~ . - mu,
                                       data = training_data,
                                       test_data = test_data,
                                       hypers = Hypers(X = X_train, Y = training_data$Y,
                                                       num_tree = Ntree, alpha = 1,
                                                       eta = 1, phi = c(1,1,1),
                                                       alpha_vec = c(1,1,1),
                                                       tgroup = times_sim,
                                                       alpha_shape_1 = 0.5),
                                       opts = Opts(num_burn = Nit, num_save = Nit,
                                                   update_s = FALSE,
                                                   update_alpha = FALSE,
                                                   update_tvp = TRUE,
                                                   update_alpha_vec = TRUE,
                                                   update_eta = TRUE,
                                                   update_phi = TRUE,
                                                   update_tau = TRUE,
                                                   update_sigma_mu = TRUE))

  fitted_DBART <- wbart(x.train = training_data[,1:20], y.train = training_data$Y,
                        x.test = test_data[,1:20], sparse = TRUE, ntree = Ntree, keepevery = 1,
                        ndpost = Nit, nskip = Nit, printevery = Nit)
  
  fitted_SBART <- softbart_regression(Y ~ . - mu,
                                      data = training_data,
                                      test_data = test_data,
                                      hypers = Hypers(X = X_train,
                                                      Y = training_data$Y,
                                                      num_tree = Ntree, alpha = 1,
                                                      alpha_shape_1 = 0.5),
                                      opts = Opts(num_burn = Nit, num_save = Nit,
                                                  update_s = TRUE, update_alpha = TRUE,
                                                  update_tau = TRUE,
                                                  update_sigma_mu = TRUE))
  

  fitted_BART <- wbart(x.train = training_data[,1:20], y.train = training_data$Y,
                       x.test = test_data[,1:20], ntree = Ntree, keepevery = 1,
                       ndpost = Nit, nskip = Nit, printevery = Nit)

  fitted_SBART_lag1 <- softbart_regression(Y ~ . - mu,
                                           data = training_data_sub,
                                           test_data = test_data_sub,
                                           hypers = Hypers(X = X_train_sub,
                                                           Y = training_data_sub$Y,
                                                           num_tree = Ntree, alpha = 1,
                                                           alpha_shape_1 = 0.5),
                                           opts = Opts(num_burn = Nit, num_save = Nit,
                                                       update_s = TRUE, update_alpha = TRUE,
                                                       update_tau = TRUE,
                                                       update_sigma_mu = TRUE))
  

    
out2 <- c(c(mean(fitted_LBART$mu_test_mean) - mtm,
            rmse(fitted_LBART$mu_test_mean, mtm),
            coverage(mtm, fitted_LBART$mu_test_mean),
            mean(fitted_LBART$mu_test_mean - test_data$mu),
            rmse(fitted_LBART$mu_test_mean, test_data$mu),
            coverage(test_data$mu, fitted_LBART$mu_test)),
          
          c(mean(fitted_DBART$yhat.test.mean) - mtm,
            rmse(fitted_DBART$yhat.test.mean, mtm),
            coverage(mtm, fitted_DBART$yhat.test.mean),
            mean(fitted_DBART$yhat.test - test_data$mu),
            rmse(fitted_DBART$yhat.test.mean, test_data$mu),
            coverage(test_data$mu, fitted_DBART$yhat.test)),
          
          c(mean(fitted_SBART$mu_test_mean) - mtm,
            rmse(fitted_SBART$mu_test_mean, mtm),
            coverage(mtm, fitted_SBART$mu_test_mean),
            mean(fitted_SBART$mu_test_mean - test_data$mu),
            rmse(fitted_SBART$mu_test_mean, test_data$mu),
            coverage(test_data$mu, fitted_SBART$mu_test)),

          c(mean(fitted_BART$yhat.test.mean) - mtm,
            rmse(fitted_BART$yhat.test.mean, mtm),
            coverage(mtm, fitted_BART$yhat.test.mean),
            mean(fitted_BART$yhat.test - test_data$mu),
            rmse(fitted_BART$yhat.test.mean, test_data$mu),
            coverage(test_data$mu, fitted_BART$yhat.test)),
          
          c(mean(fitted_SBART_lag1$mu_test_mean) - mtm,
            rmse(fitted_SBART_lag1$mu_test_mean, mtm),
            coverage(mtm, fitted_SBART_lag1$mu_test_mean),
            mean(fitted_SBART_lag1$mu_test_mean - test_data_sub$mu),
            rmse(fitted_SBART_lag1$mu_test_mean, test_data_sub$mu),
            coverage(test_data_sub$mu, fitted_SBART_lag1$mu_test)))
          

write(out2, fna2, ncolumns = 30, append = TRUE)

}
stopCluster(myCluster)
