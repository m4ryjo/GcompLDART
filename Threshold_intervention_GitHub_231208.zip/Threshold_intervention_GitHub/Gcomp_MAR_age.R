library(SBart2)
library(rBeta2009)
library(EnvStats)
library(truncnorm)
library(foreach)
library(doParallel)

source("Rfunctions.R")
source("gc_functions.R")
source("gc_softbart_regression.R")
source("gc_softbart_probit.R")

betula_data <- read.table("betula_data")

vartype_bl <- c(rep("X0",6),rep("X",3),"Y","S",
                rep("X",5),"X","Y","S",
                rep("X",4),"X","Y","S",
                rep("X",4),"X","Y")

vartype_inc <- c(rep("X0",6),rep("X",3),"Y","S",
                 rep("X",5),"Ra","Y","S",
                 rep("X",4),"Ra","Y","S",
                 rep("X",4),"Ra","Y")

tgroup <- c(rep(0,3),rep(1,8),rep(2,8),rep(3,7),rep(4,6))

drop_par <- NULL 
delta <- cbind(-2*sd(betula_data$BP_systolic.1),
               0,
               -2*sd(betula_data$BP_systolic.1) + 0.1)

n_burn <- 300
n_thin <- 100
n_save <- 150
n_tree <- 20

opts <- Opts(num_burn = n_burn, num_thin = n_thin, num_save = n_save,
             update_sigma_mu = TRUE,
             update_s = FALSE, update_alpha = FALSE,
             update_tvp = TRUE, update_alpha_vec = TRUE, update_eta = TRUE,
             update_phi = TRUE, 
             update_beta = FALSE,
             update_gamma = FALSE, update_tau = TRUE, update_tau_mean = FALSE,
             update_sigma = TRUE, cache_trees = TRUE)


myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:16, .packages = c("rBeta2009", "SBart2", "EnvStats", "truncnorm")) %dopar% {
  
  BM <- BMfits(betula_data,
               var.type = vartype_bl,
               fixed.regime = NULL, 
               drop_param = drop_par,
               above = FALSE,
               cutoff = FALSE,
               opts = opts, # opts see SoftBart
               Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
               tgroup = tgroup,
               num_tree = n_tree)
  
  ##################################################
  
  for(j in 1:8){
    age <- seq(35,70,by=5)[j]
    sub_datMA <- subset(betula_data, Age_cohort_T1 == age)
    
    frsMA <- gcompbart(sub_datMA,
                       var.type = vartype_bl,
                       fixed.regime = NULL,
                       random.regime = NULL,
                       drop_param = drop_par,
                       above = FALSE,
                       cutoff = FALSE,
                       J = 10000,
                       opts = opts, # opts see SoftBart
                       Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
                       By = 200, # If Suppress is set to FALSE, output is provided for the By:th iteration.
                       weighted = FALSE,
                       tgroup = tgroup,
                       num_tree = n_tree,
                       BModels = BM)
    
    frsMA_inc1 <- gcompbart(sub_datMA,
                            var.type = vartype_inc,
                            fixed.regime = NULL,
                            random.regime = rep("triangular", 3),
                            param = list(delta,
                                         delta,
                                         delta),
                            nat_value = TRUE,
                            above = TRUE,
                            cutoff = rep(141, 3),
                            incremental = TRUE,
                            drop_param = drop_par,
                            J = 10000,
                            opts = opts, # opts see SoftBart
                            Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
                            By = 200, # If Suppress is set to FALSE, output is provided for the By:th iteration.
                            weighted = FALSE, # if TRUE overlap weights are computed and the a weighted outcome is returned
                            tgroup = tgroup,
                            num_tree = n_tree,
                            BModels = BM)
    
    
    out <- t(rbind(frsMA$y_hat,
                   frsMA_inc1$y_hat,
                   frsMA$s_hat,
                   frsMA_inc1$s_hat))
    
    fna <- paste("MAR_out_S1_alive_lbart_3w_age", age, sep = "_")
    
    write.table(out, fna, append=TRUE, col.names = FALSE, row.names = FALSE )

  }
}
stopCluster(myCluster)
