############################################################
library(GcompBART)
library(SBart2)
library(MASS)
library(foreach)
library(doParallel)

source("Rfunctions.R")
source("sim_data.R")

########################################################
# BART specification
n_tree <- 50  
n_burn <- 300
n_thin <- 4
n_save <- 500

vartype_bl <- c(rep("X0", 5), rep("X", 15), "Y")

fna <- paste("Sim_hdart_n",n,"_Ntree",Ntree,"_l1",sep="")
########################################################

myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:650, .packages = c("MASS", "GcompBART", "SBart2")) %dopar% {
  training_data <- sim_fried(n, 20, Sig, sig, lambda)
  
  gcbfit <- GcompBART(data = training_data[,1:21], 
                      var.type = vartype_bl, 
                      J = 10000, 
                      Ndraws = n_save,
                      Suppress = TRUE,
                      Nskip = n_burn,
                      Ntree = n_tree,
                      Sparse = TRUE,
                      Keepevery = n_thin)
  
  out <- c(abs(gcbfit$summary_out[1] - mtm)/mtm, # abs relative bias 
           rmse(gcbfit$y_hat, mtm), # rmse
           coverage(mtm, gcbfit$y_hat)) # 95% coverage
  
  write(out, fna, ncolumns = 3, append = TRUE)
  
}
stopCluster(myCluster)
