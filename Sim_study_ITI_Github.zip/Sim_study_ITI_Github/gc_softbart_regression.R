gc_softbart_regression <- function(X, Y, num_tree = 20, k = 2,
                                   hypers = NULL, opts = NULL, verbose = TRUE) {

  ## Get design matricies and groups for categorical
  # data <- data.frame(X = X, Y = Y)
  # dv <- dummyVars(Y ~ X)
  # terms <- attr(dv$terms, "term.labels")
  # group <- dummy_assign(dv)
  # suppressWarnings({
  #   X_train <- predict(dv, data)
  # })
  Y_train <- Y #model.response(model.frame(formula, data))
  X_train <- X

  stopifnot(is.numeric(Y_train))
  mu_Y <- mean(Y_train)
  sd_Y <- sd(Y_train)
  Y_train <- (Y_train - mu_Y) / sd_Y

  ## Set up hypers
  if(is.null(hypers)) {
    hypers <- Hypers(X = X_train, Y = Y_train, normalize_Y = FALSE,
                     tgroup = (1:ncol(X_train) - 1)) #, tgroup_size = table(1:ncol(X_train) - 1))
  } else {
    hypers$X <- X_train
    hypers$Y <- Y_train
  }
  hypers$sigma_mu = 3 / k / sqrt(num_tree)
  hypers$num_tree <- num_tree
  hypers$group <- (1:ncol(X_train) - 1) #group

  ## Set up opts

  if(is.null(opts)) {
    opts <- Opts()
  }
  opts$num_print <- .Machine$integer.max

  ## Normalize!

  make_01_norm <- function(x) {
    a <- min(x)
    b <- max(x)
    return(function(y) (y - a) / (b - a))
  }

  ecdfs   <- list()
  for(i in 1:ncol(X_train)) {
    ecdfs[[i]] <- ecdf(X_train[,i])
    if(length(unique(X_train[,i])) == 1) ecdfs[[i]] <- identity
    if(length(unique(X_train[,i])) == 2) ecdfs[[i]] <- make_01_norm(X_train[,i])
  }
  for(i in 1:ncol(X_train)) {
    X_train[,i] <- ecdfs[[i]](X_train[,i])
  }

  ## Make forest ----
  reg_forest <- MakeForest(hypers, opts, FALSE)

  ## Initialize output

  mu_train  <- matrix(NA, nrow = opts$num_save, ncol = length(Y_train))
  sigma_mu  <- numeric(opts$num_save)
  sigma     <- numeric(opts$num_save)
  varcounts <- matrix(NA, nrow = opts$num_save, ncol = ncol(X_train))

  ## Warmup

  for(i in 1:opts$num_burn) {
    ## Update R
    mu <- reg_forest$do_gibbs(X_train, Y_train, X_train, 1)
  }

  ## Save
  for(i in 1:opts$num_save) {
    for(j in 1:opts$num_thin) {
      mu <- reg_forest$do_gibbs(X_train, Y_train, X_train, 1)
    }

    sigma_mu[i]   <- reg_forest$get_sigma_mu() * sd_Y
    sigma[i]      <- reg_forest$get_sigma() * sd_Y
    varcounts[i,] <- reg_forest$get_counts()
    #mu_train[i,]  <- mu * sd_Y + mu_Y

  }

  colnames(varcounts) <- colnames(X_train)

  out <- list(
    #sigma_mu = sigma_mu,
    var_counts = varcounts,
    sigma = sigma,
    #mu_train = mu_train,
    #mu_train_mean = colMeans(mu_train),
    opts = opts, ecdfs = ecdfs,
    mu_Y = mu_Y, sd_Y = sd_Y,
    forest = reg_forest)

  class(out) <- "softbart_regression"

  return(out)
}
