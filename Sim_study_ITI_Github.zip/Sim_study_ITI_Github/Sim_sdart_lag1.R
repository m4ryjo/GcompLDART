############################################################
library(SBart2)
library(BART)
library(MASS)
library(foreach)
library(doParallel)
library(rBeta2009)
library(EnvStats)
library(truncnorm)

source("Rfunctions.R")
source("gc_functions.R")
source("gc_softbart_regression.R")
source("gc_softbart_probit.R")



sim_fried <- function(N, P, Sigma, sigma, lambda) {
  rawvars <- mvrnorm(N, rep(0, P), Sigma)
  X <- pnorm(rawvars)
  
  drop2 <- rbinom(N, 1, expit( 0.75 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5])))
  drop3 <- rbinom(N, 1, expit( 0.40 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5] + X[,6] + X[,7] + X[,8] + X[,9] + X[,10])))
  drop4 <- rbinom(N, 1, expit( 0.25 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5] + X[,6] + X[,7] + X[,8] + X[,9] + X[,10] + X[,11] + X[,12] + X[,13] + X[,14] + X[,15])))
  
  X[drop2==0, 6:20] <- NA
  X[drop3==0, 11:20] <- NA
  X[drop4==0, 16:20] <- NA
  
  mu <- lambda[1] * (10 * sin(pi * X[,1] * X[,2]) + 20 * (X[,3] - 0.5)^2 + 10 * X[,4] + 5 * X[,5]) +
    lambda[2] * (10 * sin(pi * X[,6] * X[,7]) + 20 * (X[,8] - 0.5)^2 + 10 * X[,9] + 5 * X[,10]) +
    lambda[3] * (10 * sin(pi * X[,11] * X[,12]) + 20 * (X[,13] - 0.5)^2 + 10 * X[,14] + 5 * X[,15]) +
    lambda[4] * (10 * sin(pi * X[,16] * X[,17]) + 20 * (X[,18] - 0.5)^2 + 10 * X[,19] + 5 * X[,20])
  Y <- mu + sigma * rnorm(N)
  #X <- round(X, 1)
  
  
  return(data.frame(X = X, Y = Y, mu = mu))
}

coverage <- function(my, my_fit, proc = 0.95){
  if(length(my)==1){
    out <- ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                    my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0)
  } else {
    out <- mean(ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                         my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0))
  }
  
  return(out)
}  

########################################################
Ntree <- 50  # 1, 10, 100
n_burn <- 300
n_thin <- 4
n_save <- 500

n <- 250 # sample size 250, 1000, 2000
times_sim <- rep(1:4, each = 5) # grouping variable

# l <- 1
#k <- 3
#lambda <- c(0.25,0.5,0.75,1)^k
#lambda <- c(0,0,0,1)
lambda <- c(0.25,0.5,0.75,1)

a1 <- 0.4
a2 <- 0.2
a3 <- 0.1
sig <- 10  # 1?, 10, 25

Sig<-matrix(c(c(1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0,0),
              c(0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0),
              c(0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0),
              c(0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0),
              c(0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3),
              c(a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0),
              c(0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0),
              c(0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0),
              c(0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0),
              c(0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2),
              c(a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0),
              c(0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0),
              c(0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0),
              c(0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0),
              c(0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1),
              c(a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0),
              c(0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0),
              c(0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0),
              c(0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0),
              c(0,0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1)), 20, 20, byrow = TRUE)

vartype_bl <- c(rep("X0", 5), rep("X", 15), "Y")

tgroup <- c(rep(1:4,each=5),4)

########################################################
#fna <- paste("Sim_gcomp_ldart_n",n,"_Ntree",Ntree,"_l2",sep="") # lambda <- (c(0.25,0.5,0.75,1)^k)
 fna <- paste("Sim_gcomp_dart_lag1_n",n,"_Ntree",Ntree,"_l1_new2",sep="") #lambda <- c(0.25,0.5,0.75,1)
# fna <- paste("Sim_gcomp_ldart_n",n,"_Ntree",Ntree,"_l0",sep="") # lambda <- c(0,0,0,1)

mtm <- 36.42767
sdtm <- 8.310

myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:500, .packages = c("MASS", "SBart2", "rBeta2009", "EnvStats", "truncnorm")) %dopar% {
  training_data <- sim_fried(n, 20, Sig, sig, lambda)
  test_data <- sim_fried(n, 20, Sig, sig, lambda)
  X_train <- model.matrix(Y ~ . - 1 - mu, data = training_data)
  X_test <- model.matrix(Y ~ . - 1 - mu, data = test_data)
  
  BM <- BMfits(training_data[,1:21],
               var.type = vartype_bl,
               fixed.regime = NULL, 
               drop_param = NULL,
               above = FALSE,
               cutoff = FALSE,
               opts = Opts(num_burn = n_burn, 
                           num_thin = n_thin, 
                           num_save = n_save,
                           update_s = FALSE,
                           update_alpha = FALSE,
                           update_tvp = TRUE,
                           update_alpha_vec = TRUE,
                           update_eta = TRUE,
                           update_phi = TRUE,
                           update_tau = TRUE,
                           update_sigma_mu = TRUE), # opts see SoftBart
               Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
               tgroup = tgroup,
               Lag1 = TRUE,
               num_tree = Ntree)

  out_dartl1 <- gcompbart(training_data[,1:21],
                     var.type = vartype_bl,
                     fixed.regime = NULL,
                     random.regime = NULL,
                     drop_param = NULL,
                     above = FALSE,
                     cutoff = FALSE,
                     J = 7500,
                     opts = Opts(num_burn = n_burn, 
                                 num_thin = n_thin, 
                                 num_save = n_save,
                                 update_s = FALSE,
                                 update_alpha = FALSE,
                                 update_tvp = TRUE,
                                 update_alpha_vec = TRUE,
                                 update_eta = TRUE,
                                 update_phi = TRUE,
                                 update_tau = TRUE,
                                 update_sigma_mu = TRUE), # opts see SoftBart
                     Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
                     tgroup = tgroup,
                     num_tree = Ntree,
                     Lag1 = TRUE,
                     BModels = BM)
  
  out <- c(out_dartl1$summary_out[1], # mean_yhat
           out_dartl1$summary_out[1] - mtm, # bias
           (out_dartl1$summary_out[1] - mtm)/sdtm, # %bias 
           rmse(out_dartl1$y_hat, mtm), # rmse
           coverage(mtm, out_dartl1$y_hat)) # 95% coverage
  
  write(out, fna, ncolumns = 5, append = TRUE)
  
}
stopCluster(myCluster)
