############################################################
library(SBart2)
library(BART)
library(MASS)
library(foreach)
library(doParallel)
library(rBeta2009)
library(EnvStats)
library(truncnorm)

source("Rfunctions.R")
source("sim_data.R")
source("gc_functions.R")
source("gc_softbart_regression.R")
source("gc_softbart_probit.R")


########################################################
# BART specification
Ntree <- 50  
n_burn <- 300
n_thin <- 4
n_save <- 500

vartype_bl <- c(rep("X0", 5), rep("X", 15), "Y")

tgroup <- c(rep(1:4, each=5), 4)

fna <- paste("Sim_ldart_n",n,"_Ntree",Ntree,"_l1",sep="")
########################################################

myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:500, .packages = c("MASS", "SBart2", "rBeta2009", "EnvStats", "truncnorm")) %dopar% {
  training_data <- sim_fried(n, 20, Sig, sig, lambda)

  BM <- BMfits(training_data[,1:21],
               var.type = vartype_bl,
               fixed.regime = NULL, 
               drop_param = NULL,
               above = FALSE,
               cutoff = FALSE,
               opts = Opts(num_burn = n_burn, 
                           num_thin = n_thin, 
                           num_save = n_save,
                           update_s = FALSE,
                           update_alpha = FALSE,
                           update_tvp = TRUE,
                           update_alpha_vec = TRUE,
                           update_eta = TRUE,
                           update_phi = TRUE,
                           update_tau = TRUE,
                           update_sigma_mu = TRUE), # opts see SoftBart
               Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
               tgroup = tgroup,
               num_tree = Ntree)

  out_lbart <- gcompbart(training_data[,1:21],
                     var.type = vartype_bl,
                     fixed.regime = NULL,
                     random.regime = NULL,
                     drop_param = NULL,
                     above = FALSE,
                     cutoff = FALSE,
                     J = 10000,
                     opts = Opts(num_burn = n_burn, 
                                 num_thin = n_thin, 
                                 num_save = n_save,
                                 update_s = FALSE,
                                 update_alpha = FALSE,
                                 update_tvp = TRUE,
                                 update_alpha_vec = TRUE,
                                 update_eta = TRUE,
                                 update_phi = TRUE,
                                 update_tau = TRUE,
                                 update_sigma_mu = TRUE), # opts see SoftBart
                     Suppress = TRUE, # Indicates if the output should be suppressed. Default is TRUE
                     tgroup = tgroup,
                     num_tree = Ntree,
                     BModels = BM)
  
  out <- c(abs(out_bart$summary_out[1] - mtm)/mtm, # abs relative bias 
           rmse(out_bart$y_hat, mtm), # rmse
           coverage(mtm, out_bart$y_hat)) # 95% coverage
  
  write(out, fna, ncolumns = 3, append = TRUE)
  
}
stopCluster(myCluster)
