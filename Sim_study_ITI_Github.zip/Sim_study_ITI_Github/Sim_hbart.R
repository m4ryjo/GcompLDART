############################################################
library(GcompBART)
library(SBart2)
library(MASS)
library(foreach)
library(doParallel)


expit <- function(x) {
  exp(x)/(1+exp(x))
}

sim_fried <- function(N, P, Sigma, sigma, lambda) {
  rawvars <- mvrnorm(N, rep(0, P), Sigma)
  X <- pnorm(rawvars)
  
  drop2 <- rbinom(N, 1, expit( 0.75 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5])))
  drop3 <- rbinom(N, 1, expit( 0.40 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5] + X[,6] + X[,7] + X[,8] + X[,9] + X[,10])))
  drop4 <- rbinom(N, 1, expit( 0.25 * (X[,1] + X[,2] + X[,3] + X[,4] + X[,5] + X[,6] + X[,7] + X[,8] + X[,9] + X[,10] + X[,11] + X[,12] + X[,13] + X[,14] + X[,15])))
  
  X[drop2==0, 6:20] <- NA
  X[drop3==0, 11:20] <- NA
  X[drop4==0, 16:20] <- NA
  
  mu <- lambda[1] * (10 * sin(pi * X[,1] * X[,2]) + 20 * (X[,3] - 0.5)^2 + 10 * X[,4] + 5 * X[,5]) +
    lambda[2] * (10 * sin(pi * X[,6] * X[,7]) + 20 * (X[,8] - 0.5)^2 + 10 * X[,9] + 5 * X[,10]) +
    lambda[3] * (10 * sin(pi * X[,11] * X[,12]) + 20 * (X[,13] - 0.5)^2 + 10 * X[,14] + 5 * X[,15]) +
    lambda[4] * (10 * sin(pi * X[,16] * X[,17]) + 20 * (X[,18] - 0.5)^2 + 10 * X[,19] + 5 * X[,20])
  Y <- mu + sigma * rnorm(N)
  #X <- round(X, 1)
  
  
  return(data.frame(X = X, Y = Y, mu = mu))
}

coverage <- function(my, my_fit, proc = 0.95){
  if(length(my)==1){
    out <- ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                    my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0)
  } else {
    out <- mean(ifelse(my > quantile(my_fit, (1 - proc)/2) & 
                         my < quantile(my_fit, 1 - (1 - proc)/2), 1, 0))
  }
  
  return(out)
}  

########################################################
n_tree <- 50  # 1, 10, 100
n_burn <- 300
n_thin <- 4
n_save <- 500

n <- 750 # sample size 100, 500, 1500
times_sim <- rep(1:4, each = 5) # grouping variable

# l <- 1
#k <- 3
#lambda <- c(0.25,0.5,0.75,1)^k
#lambda <- c(0,0,0,1)
lambda <- c(0.25,0.5,0.75,1)

a1 <- 0.4
a2 <- 0.2
a3 <- 0.1
sig <- 10  # 1?, 10, 25

Sig<-matrix(c(c(1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0,0),
              c(0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0,0),
              c(0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0,0),
              c(0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3,0),
              c(0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0,a3),
              c(a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0,0),
              c(0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0,0),
              c(0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0,0),
              c(0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2,0),
              c(0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0,a2),
              c(a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0,0),
              c(0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0,0),
              c(0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0,0),
              c(0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1,0),
              c(0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0,a1),
              c(a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0,0),
              c(0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0,0),
              c(0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0,0),
              c(0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1,0),
              c(0,0,0,0,a3,0,0,0,0,a2,0,0,0,0,a1,0,0,0,0,1)), 20, 20, byrow = TRUE)

vartype_bl <- c(rep("C", 20), "O")

tgroup <- c(rep(0:3,each=5),3)

########################################################
#fna <- paste("Sim_gcomp_hbart_n",n,"_Ntree",n_tree,"_l2",sep="") # lambda <- (c(0.25,0.5,0.75,1)^k)
 fna <- paste("Sim_gcomp_hbart_n",n,"_Ntree",n_tree,"_l1_new2",sep="") #lambda <- c(0.25,0.5,0.75,1)
# fna <- paste("Sim_gcomp_hbart_n",n,"_Ntree",n_tree,"_l0",sep="") # lambda <- c(0,0,0,1)

mtm <- 36.42767
sdtm <- 8.310

myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:500, .packages = c("MASS", "GcompBART", "SBart2")) %dopar% {
  training_data <- sim_fried(n, 20, Sig, sig, lambda)
  test_data <- sim_fried(n, 20, Sig, sig, lambda)
  X_train <- model.matrix(Y ~ . - 1 - mu, data = training_data)
  X_test <- model.matrix(Y ~ . - 1 - mu, data = test_data)
  
  
  gcbfit <- GcompBART(data = training_data[,1:21], 
                      var.type = vartype_bl, 
                      J = 7500, 
                      Ndraws = n_save,
                      Suppress = TRUE,
                      Nskip = n_burn,
                      Ntree = n_tree,
                      Sparse = FALSE,
                      Keepevery = n_thin)

  out <- c(gcbfit$summary_out[1], # mean_yhat
           gcbfit$summary_out[1] - mtm, # bias
           (gcbfit$summary_out[1] - mtm)/sdtm, # %bias 
           rmse(gcbfit$y_hat, mtm), # rmse
           coverage(mtm, gcbfit$y_hat)) # 95% coverage
  
  write(out, fna, ncolumns = 5, append = TRUE)
  
}
stopCluster(myCluster)
