library(GcompLDART)
library(foreach)
library(doParallel)

betula_data <- read.table("bp_betula_data")

vartype_bl <- c(rep("X0",4),rep("X",5),"Y","S",
                rep("X",3),"X","Y","S",
                rep("X",3),"X","Y","S",
                rep("X",2),"X","Y")

vartype_inc <- c(rep("X0",4),rep("X",4),"X","Y","S",
                 rep("X",3),"Ra","Y","S",
                 rep("X",3),"Ra","Y","S",
                 rep("X",2),"Ra","Y")

tgroup <- c(rep(0,5),rep(1,6),rep(2,6),rep(3,6),rep(4,4))

drop_par <- NULL 
parameters <- cbind(c(-28.5, -40.0),
                    c(0, 0),
                    c(-28.5, -40.0) + 0.1)

n_burn <- 300
n_thin <- 100
n_save <- 150
n_tree <- 10

opts <- Opts(num_burn = n_burn, num_thin = n_thin, num_save = n_save,
             update_sigma_mu = TRUE,
             update_s = TRUE, update_alpha = TRUE,
             update_tvp = FALSE, update_alpha_vec = FALSE, update_eta = FALSE,
             update_phi = FALSE, 
             update_beta = FALSE,
             update_gamma = FALSE, update_tau = TRUE, update_tau_mean = FALSE,
             update_sigma = TRUE, cache_trees = TRUE)


myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:16, .packages = c("rBeta2009", "SBart2", "EnvStats", "truncnorm")) %dopar% {
  
  BM <- BMfits(betula_data,
               var.type = vartype_bl,
               fixed.regime = NULL, 
               drop_param = drop_par,
               above = FALSE,
               cutoff = FALSE,
               opts = opts, 
               tgroup = tgroup,
               num_tree = n_tree)
  
  
  ##################################################
  ## Middle-aged
  betula_dataMA <- subset(betula_data, age_cohort_T.1 < 55)

  frsMA <- gcompbart(betula_dataMA,
                     var.type = vartype_bl,
                     fixed.regime = NULL,
                     random.regime = NULL,
                     drop_param = drop_par,
                     above = FALSE,
                     cutoff = FALSE,
                     J = 10000,
                     opts = opts, 
                     tgroup = tgroup,
                     num_tree = n_tree,
                     BModels = BM)

  frsMA_inc1 <- gcompbart(betula_dataMA,
                          var.type = vartype_inc,
                          fixed.regime = NULL,
                          random.regime = rep("triangular", 3),
                          param = list(parameters[1, ],
                                       parameters[1, ],
                                       parameters[1, ]),
                          nat_value = TRUE,
                          above = TRUE,
                          cutoff = rep(121, 3),
                          incremental = TRUE,
                          drop_param = drop_par,
                          J = 10000,
                          opts = opts,
                          tgroup = tgroup,
                          num_tree = n_tree,
                          BModels = BM)

  ########################################################
  ## Old
  betula_dataO <- subset(betula_data, age_cohort_T.1 > 50 & age_cohort_T.1 < 75)

  frsO <- gcompbart(betula_dataO,
                   var.type = vartype_bl,
                   fixed.regime = NULL, #list(35,65),
                   random.regime = NULL,
                   drop_param = drop_par,
                   above = FALSE,
                   cutoff = FALSE,
                   J = 10000,
                   opts = opts, 
                   tgroup = tgroup,
                   num_tree = n_tree,
                   BModels = BM)
  

  frsO_inc3 <- gcompbart(betula_dataO,
                        var.type = vartype_inc,
                        fixed.regime = NULL,
                        random.regime = rep("triangular", 3),
                        param = list(parameters[2, ],
                                     parameters[2, ],
                                     parameters[2, ]),
                        nat_value = TRUE,
                        above = TRUE,
                        cutoff = rep(146, 3),
                        incremental = TRUE,
                        drop_param = drop_par,
                        J = 10000,
                        opts = opts, 
                        tgroup = tgroup,
                        num_tree = n_tree,
                        BModels = BM)
  
 
  out <- t(rbind(frsMA$y_hat,
               frsMA_inc1$y_hat,
               frsMA$s_hat,
               frsMA_inc1$s_hat,
               frsO$y_hat,
               frsO_inc3$y_hat,
               frsO$s_hat,
               frsO_inc3$s_hat))

  write.table(out, "MAR_out_alive_sbart", append=TRUE, col.names = FALSE, row.names = FALSE )
}
stopCluster(myCluster)
