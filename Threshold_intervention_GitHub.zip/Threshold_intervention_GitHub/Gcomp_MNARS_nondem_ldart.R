library(GcompLDART)
library(foreach)
library(doParallel)

bp_betula_data_mnar <- read.table("bp_betula_data_mnar_nondem")

vartype_bl <- c(rep("X0",4),rep("X",5),"Y","S","D",
                rep("X",3),"X","Y","S","D",
                rep("X",3),"X","Y","S","D",
                rep("X",2),"X","Y")

vartype_inc <- c(rep("X0",4),rep("X",4),"Ra","Y","S","D",
                 rep("X",3),"Ra","Y","S","D",
                 rep("X",3),"Ra","Y","S","D",
                 rep("X",2),"Ra","Y")

tgroup <- c(rep(0,5),rep(1,7),rep(2,7),rep(3,7),rep(4,6))

drop_parMA <- list(c(-2/76, 0, -1.99/76),
                   c(-2/76, 0, -1.99/76),
                   c(-2/76, 0, -1.99/76),
                   c(-2/76, 0, -1.99/76))

drop_parO <- list(c(-2/76, 0, -1.99/76),
                  c(-2/76, 0, -1.99/76),
                  c(-2/76, 0, -1.99/76),
                  c(-2/76, 0, -1.99/76))

parameters <- cbind(c(-28.5, -40.0),
                    c(0, 0),
                    c(-28.5, -40.0) + 0.1)

n_burn <- 300
n_thin <- 100
n_save <- 150
n_tree <- 10

opts <- Opts(num_burn = n_burn, num_thin = n_thin, num_save = n_save,
             update_sigma_mu = TRUE,
             update_s = FALSE, update_alpha = FALSE,
             update_tvp = TRUE, update_alpha_vec = TRUE, update_eta = TRUE,
             update_phi = TRUE, 
             update_beta = FALSE,
             update_gamma = FALSE, update_tau = TRUE, update_tau_mean = FALSE,
             update_sigma = TRUE, cache_trees = TRUE)


myCluster <- makeCluster(16)
registerDoParallel(myCluster)

foreach(i=1:16, .packages = c("GcompLDART")) %dopar% {
  
  BM <- BMfits(bp_betula_data_mnar,
               var.type = vartype_bl,
               fixed.regime = NULL, 
               drop_param = drop_par,
               above = FALSE,
               cutoff = FALSE,
               opts = opts, 
               Suppress = TRUE, 
               tgroup = tgroup,
               num_tree = n_tree)
  
  
  ##################################################
  ## Middle-aged
  bp_betula_data_mnarMA <- subset(bp_betula_data_mnar, age_cohort_T.1 < 55)

  frsMA <- gcompbart(bp_betula_data_mnarMA,
                     var.type = vartype_bl,
                     fixed.regime = NULL,
                     random.regime = NULL,
                     drop_param = drop_parMA,
                     above = FALSE,
                     cutoff = FALSE,
                     J = 10000,
                     opts = opts, 
                     Suppress = TRUE, 
                     tgroup = tgroup,
                     num_tree = n_tree,
                     BModels = BM)

  frsMA_inc1 <- gcompbart(bp_betula_data_mnarMA,
                          var.type = vartype_inc,
                          fixed.regime = NULL,
                          random.regime = rep("triangular", 3),
                          param = list(parameters[1, ],
                                       parameters[1, ],
                                       parameters[1, ]),
                          nat_value = TRUE,
                          above = TRUE,
                          cutoff = rep(120, 3),
                          incremental = TRUE,
                          drop_param = drop_parMA,
                          J = 10000,
                          opts = opts, 
                          Suppress = TRUE, 
                          tgroup = tgroup,
                          num_tree = n_tree,
                          BModels = BM)


  ########################################################
  ## Old
  bp_betula_data_mnarO <- subset(bp_betula_data_mnar, age_cohort_T.1 > 50 & age_cohort_T.1 < 75)

  frsO <- gcompbart(bp_betula_data_mnarO,
                   var.type = vartype_bl,
                   fixed.regime = NULL, 
                   random.regime = NULL,
                   drop_param = drop_parO,
                   above = FALSE,
                   cutoff = FALSE,
                   J = 10000,
                   opts = opts, 
                   Suppress = TRUE, 
                   tgroup = tgroup,
                   num_tree = n_tree,
                   BModels = BM)
  
  frsO_inc3 <- gcompbart(bp_betula_data_mnarO,
                        var.type = vartype_inc,
                        fixed.regime = NULL,
                        random.regime = rep("triangular", 3),
                        param = list(parameters[2, ],
                                     parameters[2, ],
                                     parameters[2, ]),
                        nat_value = TRUE,
                        above = TRUE,
                        cutoff = rep(145, 3),
                        incremental = TRUE,
                        drop_param = drop_parO,
                        J = 10000,
                        opts = opts, 
                        tgroup = tgroup,
                        num_tree = n_tree,
                        BModels = BM)
  

  out <- t(rbind(frsMA$y_hat,
               frsMA_inc1$y_hat,
               frsMA$s_hat,
               frsMA_inc1$s_hat,
               frsO$y_hat,
               frsO_inc3$y_hat,
               frsO$s_hat,
               frsO_inc3$s_hat))

  write.table(out, "MNARS_35_70", append=TRUE, col.names = FALSE, row.names = FALSE )
}
stopCluster(myCluster)
